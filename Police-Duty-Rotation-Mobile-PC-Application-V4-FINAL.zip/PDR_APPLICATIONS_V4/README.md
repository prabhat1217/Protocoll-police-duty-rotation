# Police Duty Rotation — Mobile + PC Application V4

This package contains the same V4 application UI/logic for:
- Windows PC: Electron application project
- Android Mobile: Android WebView application project

Both applications use the same V4 `index.html` logic so duty allocation behavior stays consistent.

Build outputs are generated from the included cloud build workflows.

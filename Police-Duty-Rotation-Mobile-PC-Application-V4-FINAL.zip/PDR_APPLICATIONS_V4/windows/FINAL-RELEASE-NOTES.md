Police Duty Rotation — Final Release Notes

Core rule added/confirmed:
1. Same-day VIP/PM/CM return journey on the SAME route keeps the same people already assigned to the same points.
2. If the return/next duty uses a DIFFERENT route, allocation is generated for that route using rotation history.
3. Rotation is point + route + rank aware and prefers staff who have not recently handled that exact point.
4. Unavailable / leave / training / other-duty staff are excluded.
5. A person cannot be assigned to two points in the same day's allocation.
6. Existing same-day valid assignments are preserved when the allocation screen is run again.
7. Existing legacy localStorage duty records remain readable; new records also store a stable employee key where possible.

The same HTML core is used by the Windows and Android packages.
